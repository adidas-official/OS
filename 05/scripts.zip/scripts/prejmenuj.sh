#!/bin/bash

cd ./cv5;
pwd;
for i in one two three; do
	mv $i $i.html;
done
exit 0
