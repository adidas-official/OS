#!/bin/bash

ls -l *.sh | wc -l
