#!/bin/bash

sed = names1.txt | sed 'N;s/\n/ /'
