#!/bin/bash

ls -lahG /home/dev/studium/vspj/4.sem/OS/04/ukol/screens > /home/dev/studium/vspj/4.sem/OS/04/ukol/commands/screensDir.txt
