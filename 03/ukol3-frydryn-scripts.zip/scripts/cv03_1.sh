#!/bin/bash

sed -n '3p' $1
