#!/bin/bash

full_name="${1} a ${2}"
echo $full_name
echo "Pocet argumentu: $#"
echo "Script: $0"
echo "PID: $$"
